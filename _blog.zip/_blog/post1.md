---
layout: blog
title: "My First Blog Post"
date: 2024-07-16
---

This is the content of my first blog post. I can write about anything here, including short stories or daily updates.
